col i_am_exadata format a12

select cast(extractvalue(
                          dbms_xmlgen.getxmltype(
                                                 to_clob(
                                                          (
                                                            select 'select lpad(cast(''YES - ''||count(distinct cell_name) as varchar2(12)),12,'' '') cell_count from gv$cell_state'
                                                            from dual
                                                            where exists (select null from dba_synonyms where synonym_name = 'GV$CELL_STATE' and owner = 'PUBLIC')
                                                            union all
                                                            select 'select lpad(''Not EXADATA'',12,'' '') cell_count from dual'
                                                            from dual
                                                            where not exists (select null from dba_synonyms where synonym_name = 'GV$CELL_STATE' and owner = 'PUBLIC')
                                                          )
                                                        )
                                                 )
                                           ,'/ROWSET/ROW/CELL_COUNT'
                        ) as varchar2(12)
           ) am_i_exadata
from dual
/
