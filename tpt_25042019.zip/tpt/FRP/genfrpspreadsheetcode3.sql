set linesize 999
set trimspool on
set trimout on
col text format a900

col zzselect_id noprint
col zztable_owner noprint
col zztable_name noprint

col owner format a30
col object_name format a30
col object_type format a15 trunc


select 0.1 zzselect_id,null zztable_owner,null zztable_name,'with' from dual union all
select 0.2 zzselect_id,null zztable_owner,null zztable_name,'     filteringcount_data as (' from dual union all
select 1 zzselect_id,null zztable_owner,null zztable_name,'          select id,table_owner,table_name,filtered_rowcount,cardinality from (' from dual union all
select 2 select_id,table_owner,table_name,'             select '''||lpad(id,4,' ')||''' id,count(*) filtered_rowcount,'''||table_owner||''' table_owner,'''||table_name||''' table_name,'||cardinality||' cardinality from '||table_owner||'.'||table_name||case
                                                                     when access_predicates is null and filter_predicates is null then null
                                                                     when access_predicates is null and filter_predicates is not null then ' '||substr(object_alias,1,instr(object_alias,'@')-1)||' where '||filter_predicates
                                                                     when access_predicates is not null and filter_predicates is null then ' '||substr(object_alias,1,instr(object_alias,'@')-1)||' where '||access_predicates
                                                                     when access_predicates is not null and filter_predicates is not null and access_predicates != filter_predicates then ' '||substr(object_alias,1,instr(object_alias,'@')-1)||' where '||access_predicates||' and '||filter_predicates
                                                                     else ' '||substr(object_alias,1,instr(object_alias,'@')-1)||' where '||access_predicates
                                                              end||' union all' text
from (
       select * from (
                       select x.id,x.table_owner,x.table_name,x.object_alias,x.cardinality
                             ,case when
                                        instr(replace(x.access_predicates,'"="'),'=') > 0 or
                                        instr(replace(x.access_predicates,'">"'),'>') > 0 or
                                        instr(replace(x.access_predicates,'"<"'),'<') > 0 or
                                        instr(replace(x.access_predicates,'">="'),'>=') > 0 or
                                        instr(replace(x.access_predicates,'"<="'),'<=') > 0 or
                                        instr(replace(x.access_predicates,'"!="'),'!=') > 0 or
                                        instr(replace(x.access_predicates,'"<>"'),'<>') > 0 or
                                        instr(replace(x.access_predicates,'" LIKE "'),' LIKE ') > 0 or
                                        instr(replace(x.access_predicates,'" BETWEEN "'),' BETWEEN ') > 0 or
                                        instr(replace(x.access_predicates,'" IN ("'),' IN (') > 0 or
                                        instr(replace(x.access_predicates,'" NOT LIKE "'),' NOT LIKE ') > 0 or
                                        instr(replace(x.access_predicates,'" NOT BETWEEN "'),' NOT BETWEEN ') > 0 or
                                        instr(replace(x.access_predicates,'" NOT IN ("'),' NOT IN (') > 0
                                   then x.access_predicates
                              end access_predicates
                             ,case when
                                        instr(replace(x.filter_predicates,'"="'),'=') > 0 or
                                        instr(replace(x.filter_predicates,'">"'),'>') > 0 or
                                        instr(replace(x.filter_predicates,'"<"'),'<') > 0 or
                                        instr(replace(x.filter_predicates,'">="'),'>=') > 0 or
                                        instr(replace(x.filter_predicates,'"<="'),'<=') > 0 or
                                        instr(replace(x.filter_predicates,'"!="'),'!=') > 0 or
                                        instr(replace(x.filter_predicates,'"<>"'),'<>') > 0 or
                                        instr(replace(x.filter_predicates,'" LIKE "'),' LIKE ') > 0 or
                                        instr(replace(x.filter_predicates,'" BETWEEN "'),' BETWEEN ') > 0 or
                                        instr(replace(x.filter_predicates,'" IN ("'),' IN (') > 0 or
                                        instr(replace(x.filter_predicates,'" NOT LIKE "'),' NOT LIKE ') > 0 or
                                        instr(replace(x.filter_predicates,'" NOT BETWEEN "'),' NOT BETWEEN ') > 0 or
                                        instr(replace(x.filter_predicates,'" NOT IN ("'),' NOT IN (') > 0
                                   then x.filter_predicates
                              end filter_predicates
                       from (
                              select a.id,a.object_owner table_owner,a.object_name table_name,a.access_predicates,a.filter_predicates,a.object_alias,a.cardinality
                              from plan_table a
                                  ,dba_tables b
                              where b.owner = a.object_owner
                              and b.table_name = a.object_name
                              and (a.access_predicates is not null or a.filter_predicates is not null)
                              union all
                              select a.id,b.table_owner,b.table_name object_name,a.access_predicates,a.filter_predicates,a.object_alias,a.cardinality
                              from plan_table a
                                  ,dba_indexes b
                              where b.owner = a.object_owner
                              and b.index_name = a.object_name
                              and (a.access_predicates is not null or a.filter_predicates is not null)
                           ) x
                  )
      where not (access_predicates is null and filter_predicates is null)
     )
union all
select 3 select_id,null,null,'             select null,null,null,null,null from dual' from dual union all
select 4 select_id,null,null,'          ) where table_name is not null order by table_owner,table_name' from dual union all
select 5 select_id,null,null,'     )' from dual union all
select 6 zzselect_id,null zztable_owner,null zztable_name,'   , rowcount_data as (' from dual union all
select 11 zzselect_id,cast(null as varchar2(30)) zzowner,cast(null as varchar2(30)) zzobject_name,'             select a.owner,a.object_name,a.object_type,nvl((select round(num_rows) from dba_tables b where b.table_name = a.object_name and b.owner = a.owner),0) num_rows,a.rowcount from (' from dual
union all
select 12 select_id,owner,object_name,'                select count(*) rowcount,'''||owner||''' owner,'''||object_name||''' object_name,'''||object_type||''' object_type from '||owner||'.'||object_name||' union all'
from dba_objects
where (owner,object_name) in (
                               select owner,table_name from dba_tables a,plan_table b where b.object_owner = a.owner and b.object_name = a.table_name
                               union
                               select table_owner,table_name from dba_indexes a,plan_table b where b.object_owner = a.owner and b.object_name = a.index_name
                             )
and object_type = 'TABLE'
union all
select 13 select_id,cast(null as varchar2(30)) owner,cast(null as varchar2(30)) object_name,'                select null,null,null,null from dual' from dual union all
select 14 select_id,cast(null as varchar2(30)) owner,cast(null as varchar2(30)) object_name,'             ) a where object_name is not null' from dual union all
select 15 select_id,null,null,'     )' from dual union all
select 16 select_id,null,null,'select rowcount_data.*' from dual union all
select 17 select_id,null,null,'      ,filteringcount_data.id,filteringcount_data.filtered_rowcount,filteringcount_data.cardinality plan_cardinality' from dual union all
select 17.1 select_id,null,null,'      ,round(filteringcount_data.filtered_rowcount/decode(rowcount_data.rowcount,0,null,rowcount_data.rowcount)*100) pct_rows_remaining' from dual union all
select 17.2 select_id,null,null,'      ,round(filteringcount_data.cardinality/decode(rowcount_data.num_rows,0,null,rowcount_data.num_rows)*100) plan_pct_rows_remaining' from dual union all
select 18 select_id,null,null,'from rowcount_data' from dual union all
select 19 select_id,null,null,'    ,filteringcount_data' from dual union all
select 20 select_id,null,null,'where rowcount_data.owner = filteringcount_data.table_owner(+)' from dual union all
select 21 select_id,null,null,'and rowcount_data.object_name = filteringcount_data.table_name(+)' from dual union all
select 22 select_id,null,null,'/' from dual
order by 1,2,3
/


/*
explain plan for ...

@genfrpspreadsheetcode.sql

19:08:35 SQL> with
19:08:49   2       filteringcount_data as (
19:08:49   3            select table_owner,table_name,filtered_rowcount from (
19:08:49   4               select count(*) filtered_rowcount,'CLAIM' table_owner,'ELIGIBILITY_DATA' table_name from CLAIM.ELIGIBILITY_DATA ED where NVL("ED"."VALUE",'Y')='N' union all
19:08:49   5               select count(*) filtered_rowcount,'CLAIMREF' table_owner,'ELIGIBILITY_REF_DATA' table_name from CLAIMREF.ELIGIBILITY_REF_DATA ERD where (UPPER("ERD"."DSCRPTN")='FMLA SERVICES INDICATOR' OR UPPER("ERD"."DSCRPTN")='LEAVE MANAGEMENT SERVICES INDICATOR') union all
19:08:49   6               select null,null,null from dual
19:08:49   7            ) where table_name is not null order by table_owner,table_name
19:08:49   8       )
19:08:49   9     , rowcount_data as (
19:08:49  10               select a.owner,a.object_name,a.object_type,(select round(num_rows) from dba_tables b where b.table_name = a.object_name and b.owner = a.owner) num_rows,a.rowcount from (
19:08:49  11                  select count(*) rowcount,'CLAIM' owner,'ELIGIBILITY_DATA' object_name,'TABLE' object_type from CLAIM.ELIGIBILITY_DATA union all
19:08:49  12                  select count(*) rowcount,'CLAIMREF' owner,'ELIGIBILITY_REF_DATA' object_name,'TABLE' object_type from CLAIMREF.ELIGIBILITY_REF_DATA union all
19:08:50  13                  select null,null,null,null from dual
19:08:50  14               ) a where object_name is not null
19:08:50  15       )
19:08:50  16  select rowcount_data.*
19:08:50  17        ,filteringcount_data.filtered_rowcount
19:08:50  18        ,round(nvl(filteringcount_data.filtered_rowcount,rowcount_data.rowcount)/decode(rowcount_data.rowcount,0,null,rowcount_data.rowcount)*100) pct_rows_remaining
19:08:50  19  from rowcount_data
19:08:50  20      ,filteringcount_data
19:08:50  21  where rowcount_data.owner = filteringcount_data.table_owner(+)
19:08:50  22  and rowcount_data.object_name = filteringcount_data.table_name(+)
19:08:50  23  /

OWNER    OBJECT_NAME          OBJEC   NUM_ROWS   ROWCOUNT FILTERED_ROWCOUNT PCT_ROWS_REMAINING
-------- -------------------- ----- ---------- ---------- ----------------- ------------------
CLAIM    ELIGIBILITY_DATA     TABLE   92836040  336800286           7024073                  2
CLAIMREF ELIGIBILITY_REF_DATA TABLE         13       5899                91                  2

2 rows selected.

Elapsed: 00:12:22.66
19:21:12 SQL> 
*/
