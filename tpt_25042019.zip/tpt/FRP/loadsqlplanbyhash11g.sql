delete from plan_table;

insert into plan_table
(
 ACCESS_PREDICATES
,BYTES
,CARDINALITY
,COST
,CPU_COST
,DEPTH
,DISTRIBUTION
,FILTER_PREDICATES
,ID
,IO_COST
,OBJECT_ALIAS
,OBJECT_NAME
,OBJECT_NODE
,OBJECT_OWNER
,OBJECT_TYPE
,OPERATION
,OPTIMIZER
,OPTIONS
,OTHER
,OTHER_TAG
,OTHER_XML
,PARENT_ID
,PARTITION_ID
,PARTITION_START
,PARTITION_STOP
,POSITION
,PROJECTION
,QBLOCK_NAME
,REMARKS
,SEARCH_COLUMNS
,TEMP_SPACE
,TIME
,TIMESTAMP
--
,PLAN_ID
,STATEMENT_ID
)
with
     plan_key as (
                   select *
                   from (
                          select inst_id,sql_id,plan_hash_value,child_number
                          from gv$sql_plan
                          where hash_value = &&1
                          order by 1,2,3,4
                        )
                   where rownum = 1
                 )
select
 ACCESS_PREDICATES
,BYTES
,CARDINALITY
,COST
,CPU_COST
,DEPTH
,DISTRIBUTION
,FILTER_PREDICATES
,ID
,IO_COST
,OBJECT_ALIAS
,OBJECT_NAME
,OBJECT_NODE
,OBJECT_OWNER
,OBJECT_TYPE
,OPERATION
,OPTIMIZER
,OPTIONS
,OTHER
,OTHER_TAG
,OTHER_XML
,PARENT_ID
,PARTITION_ID
,PARTITION_START
,PARTITION_STOP
,POSITION
,PROJECTION
,QBLOCK_NAME
,REMARKS
,SEARCH_COLUMNS
,TEMP_SPACE
,TIME
,TIMESTAMP
--
,1
,1
from gv$sql_plan
where (inst_id,sql_id,plan_hash_value,child_number) = (select * from plan_key)
/
