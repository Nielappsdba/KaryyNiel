set pagesize 50000
set linesize 999
set feedback 1
set timing on
set time on
set tab off
set trimspool on
set trimout on
set echo off
set verify off

alter session set nls_date_format = 'dd-mon-rrrr hh24:mi:ss';


col column_name format a30
col object_name format a30


@showme

