col host_name format a30

select user,sysdate,name,dbid,instance_number,instance_name,host_name,version,sid from v$database,v$instance,v$session where v$session.audsid = userenv('sessionid');
