select inst_id,sid,event,osuser,username,machine
from gv$session
where username = user
order by inst_id,sid
/
