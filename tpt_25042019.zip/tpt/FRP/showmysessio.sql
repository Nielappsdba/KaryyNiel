select /*+ rule */ *
from gv$sess_io
where (inst_id,sid) in (select inst_id,sid from gv$session where username = user)
order by inst_id,sid
/
