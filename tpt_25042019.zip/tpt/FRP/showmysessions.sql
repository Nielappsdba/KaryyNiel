select  gv$process.spid
       ,gv$session.inst_id
       ,v$session.audsid local_audsid
       ,gv$session.audsid rac_audsid
       ,gv$session.*
from gv$session
    ,gv$process
    ,v$session
where gv$session.username = user
and v$session.username = user
and v$session.audsid = userenv('sessionid')
and gv$process.addr = gv$session.paddr
and gv$process.inst_id = gv$session.inst_id
/
