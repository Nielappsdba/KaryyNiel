select sid,username,audsid,logon_time from v$session where audsid=userenv('sessionid')
/
