select username,default_tablespace
      ,(select round(sum(bytes)/1024/1024/1024,2) from dba_free_space b where b.tablespace_name = user_users.default_tablespace) free_gb
      ,temporary_tablespace
from user_users
/
