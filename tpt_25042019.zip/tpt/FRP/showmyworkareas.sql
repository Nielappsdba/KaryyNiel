col SQL_HASH_VALUE noprint
col SQL_EXEC_START       noprint
col WORKAREA_ADDRESS noprint
col QCINST_ID      noprint
col QCSID noprint
col ACTIVE_TIME noprint
col SQL_EXEC_ID noprint
col operation_type format a20

break on inst_id skip 1 dup on sid skip 1 dup on sql_id skip 1 dup


select * from gv$sql_workarea_active where (inst_id,sid) in (select inst_id,sid from gv$session where username = user)
and (sid,inst_id) not in (select sys_context('userenv','sid'),sys_context('userenv','instance') from dual)
order by inst_id,sid,sql_id,operation_id
/

