--
-- given an object name
-- show what schema owns it and what it is
--

col object_name format a30
col owner format a30
col obuject_type format a30


select owner,object_name,object_type,status
from dba_objects
where object_name = upper('&&1')
union all
select owner,db_link,'DBLINK',null
from dba_db_links
where db_link like upper('&&1%')
order by 1,2,3
/
