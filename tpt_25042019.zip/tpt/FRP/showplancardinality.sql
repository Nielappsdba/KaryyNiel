with
      table_list as (
                       select id,cardinality,object_owner table_owner,object_name table_name,cast(null as varchar2(30)) index_owner,cast(null as varchar2(30)) index_name
                       from plan_table
                       where object_type = 'TABLE'
                       and plan_id = (select max(plan_id) from plan_table)
                       union
                       select a.id,a.cardinality,b.table_owner,b.table_name,a.object_owner index_owner,a.object_name index_name
                       from plan_table a
                           ,dba_indexes b
                       where a.object_type like 'INDEX%'
                       and a.object_owner = b.owner
                       and a.object_name = b.index_name
                       and a.plan_id = (select max(plan_id) from plan_table)
                    )
select *
from table_list
/
