select plan_table_output from table(dbms_xplan.display_cursor(&&1,&&2,format=>'ADVANCED'));
