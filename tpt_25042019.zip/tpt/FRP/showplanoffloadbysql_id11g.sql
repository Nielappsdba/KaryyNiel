SELECT
plan_line_id id
, ROUND(physical_read_bytes /1048576) phyrd_mb
, ROUND(io_interconnect_bytes /1048576) ret_mb
, (1-(io_interconnect_bytes/NULLIF(physical_read_bytes,0)))*100 "SAVING%"
, LPAD(' ',plan_depth) || plan_operation||' '||plan_options||' '||plan_object_name operation
FROM v$sql_plan_monitor
WHERE sql_id = '&&1'
/

