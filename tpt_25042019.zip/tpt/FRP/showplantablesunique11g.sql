col object_owner format a30
col showconstraints format a90
col showindexes format a90
col sanity_query format a132
col metadata_ddl format a132
col get_stats format a100


select owner,table_name,num_rows,last_analyzed
from dba_tables
where (owner,table_Name) in
(
with
     my_plan_table as (
                        select *
                        from plan_table
                        where plan_id = (select max(plan_id) from plan_table)
                      )
   , table_list as (
                     select object_owner,object_name
                     from my_plan_table
                     where object_type like 'TABLE%'
                     union
                     select b.table_owner,b.table_name
                     from my_plan_table a
                         ,dba_indexes b
                     where a.object_type like 'INDEX%'
                     and a.object_owner = b.owner
                     and a.object_name = b.index_name
                   )
select  object_owner
      , object_name
from table_list
)
order by 1,2
/
