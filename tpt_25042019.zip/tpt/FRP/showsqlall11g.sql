define vinst_id = 0
define vsql_id  = 0
define vchild_number  = 0

col inst_id new_value vinst_id
col sql_id new_value vsql_id
col child_number new_value vchild_number

prompt Requested SQL Statement Identifier
select &&1 inst_id,'&&2' sql_id,&&3 child_number from dual
/

col inst_id clear
col sql_id clear
col child_number clear

prompt @showsqlchildren11g &&vsql_id
@showsqlchildren11g &&vsql_id

prompt @showsql11g &&vsql_id
@showsql11g &&vsql_id

delete from plan_table;
prompt @loadplanfromcache11g &&vinst_id &&vsql_id &&vchild_number
@loadplanfromcache11g &&vinst_id &&vsql_id &&vchild_number

prompt @showplan11gshort
@showplan11gshort

prompt @showplantablesunique11g
@showplantablesunique11g

prompt @showplanfrpspreadsheetcode11g
@showplanfrpspreadsheetcode11g

col col_wrap newline

select distinct 'variable '||replace(name,':')||' '||case when substr(datatype_string,1,3) = 'NUM' then datatype_string
                                                          when substr(datatype_string,1,3) = 'CHA' then datatype_string
                                                          when substr(datatype_string,1,3) = 'VAR' then 'varchar2(30)'
                                                          when substr(datatype_string,1,3) = 'DAT' then 'varchar2(30)'
                                                          else 'TYPE NOT SUPPORTED '||datatype_string
                                                          end col_wrap
               ,'begin '||name||' := '''||
                                          case when substr(datatype_string,1,3) = 'NUM' then value_string
                                               when substr(datatype_string,1,3) = 'CHA' then value_string
                                               when substr(datatype_string,1,3) = 'VAR' then value_string
                                               when substr(datatype_string,1,3) = 'DAT' then value_string
                                               else 'null;'
                                          end 
                                        ||'''; end;' col_wrap,'/' col_wrap
from gv$sql_bind_capture
where inst_id = &&vinst_id
and sql_id = '&&vsql_id'
and child_number = &&vchild_number
and last_captured = (
                      select max(LAST_CAPTURED) last_captured
                      from gv$sql_bind_capture
                      where inst_id = &&vinst_id
                      and sql_id = '&&vsql_id'
                      and child_number = &&vchild_number
                    )
/
