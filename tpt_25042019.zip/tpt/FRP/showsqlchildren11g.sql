col sql_text format a200 trunc

select
       inst_id,sql_id,child_number
      ,cast('@loadplanfromcache11g '||inst_id||' '||sql_id||' '||child_number as varchar2(40)) helper1
      ,cast('@showsql11g '||sql_id as varchar2(30)) helper2
      ,executions
      ,round(ELAPSED_TIME/1000000,2) elapsed_seconds
      ,round((CLUSTER_WAIT_TIME/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end)*100,2) pct_CLUSTER_WAIT_TIME
      ,round((CONCURRENCY_WAIT_TIME/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end)*100,2) pct_CONCURRENCY_WAIT_TIME
      ,round((USER_IO_WAIT_TIME/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end)*100,2) pct_USER_IO_WAIT_TIME
      ,round((PLSQL_EXEC_TIME/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end)*100,2) pct_PLSQL_EXEC_TIME
      ,round((JAVA_EXEC_TIME/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end)*100,2) pct_JAVA_EXEC_TIME
      ,round((CPU_TIME/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end)*100,2) pct_CPU_TIME
      ,round((ELAPSED_TIME - (CPU_TIME+JAVA_EXEC_TIME+PLSQL_EXEC_TIME+USER_IO_WAIT_TIME+CONCURRENCY_WAIT_TIME+CLUSTER_WAIT_TIME))/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end*100,2) other_pct
      ,replace(sql_text,chr(13),' ') sql_text
from gv$sql 
where sql_id = '&&1'
order by inst_id,sql_id,child_number
/
