set linesize 999
set pagesize 50000
set feedback 1
set trimspool on
set trimout on
set doc off
clear breaks
clear computes

col fill1 head ''
col ELAPSED_SECONDS head 'elapsed|seconds' format 999999999990
col PCT_CLUSTER_WAIT_TIME head '% in|cluster|wait' format 990
col PCT_CONCURRENCY_WAIT_TIME head '% in|concurrency|wait' format 990
col PCT_USER_IO_WAIT_TIME head '% in|userio|wait' format 990
col PCT_PLSQL_EXEC_TIME head '% in|plsql|exec' format 990
col PCT_JAVA_EXEC_TIME head '% in|java|exec' format 990
col PCT_CPU_TIME head '% in|cpu|exec' format 990
col OTHER_PCT head '% in|other|exec' format 990

col CPU_SECONDS  head 'CPU|secs'
col EPLAPSED_SECONDS  head 'ELAPSED|secs'
col EXECUTIONS  head 'Executions'
col CPU_SEC_PER_EXEC  head 'CPU secs|per Exec'
col ELA_SEC_PER_EXEC  head 'ELA secs|per Exec'
col HOURS_IN_CACHE  head 'Hours|in Cache'


-- alter session set nls_date_format = 'dd-mon-rrrr hh24:mi:ss';

@showme

select * from v$version
/

@am_i_exadata

select
       inst_id
      ,instance_name
      ,startup_time
      ,round((sysdate-startup_time),1) up_days
      ,round(round((sysdate-startup_time),1)*24) maximum_cache_hours
      ,to_char(sysdate,'dd-mon-rrrr hh24:mi:ss') right_now
from gv$instance
order by inst_id
/

--
-- show how long the database has been up, how many cpus are available, and thus the theoretical CPU available
--
compute sum of available_cpu_hours on report
break on report
select
       inst_id
      ,instance_name
      ,(select cpu_count_highwater from sys.v_$license) cpu_count
      ,round((round((sysdate-startup_time),1)*24)*(select cpu_count_highwater from sys.v_$license)) available_cpu_hours
from gv$instance
order by inst_id
/

show parameter parallel_threads_per_cpu

col pct_total format 990
compute sum of sql_statements on inst_id
compute sum of sql_statements on report
compute sum of db_pct_total on inst_id
compute sum of db_pct_total on report
compute sum of running_consumed_cpu_hours on report
break on inst_id dup skip page on report

--
-- use a logarithmic scale to plot cpu consumtion of all queries in the cache
-- we can use this to zero in on the top consumers
-- notice we exclude PLSQL CALLS but not the sql inside these calls
-- this gives us the true SQL workload
--
select 
       inst_id
      ,cpu_time_log10
      ,sql_statements
      ,cpu_time_rounded,round(cpu_time) cpu_time
      ,round(100*ratio_to_report(cpu_time) over(partition by inst_id)) inst_pct_total
      ,round(100*ratio_to_report(cpu_time) over()) db_pct_total
      ,round(sum(cpu_time) over (partition by inst_id order by cpu_time_log10)) running_cpu_time
      ,round(round(sum(cpu_time) over (partition by inst_id order by cpu_time_log10))/60/60,2) running_consumed_cpu_hours
--
      ,'-----' fill1
      ,round(xELAPSED_TIME/1000000,2) elapsed_seconds
      ,round((xCLUSTER_WAIT_TIME/case when xELAPSED_TIME = 0 then null else xELAPSED_TIME end)*100,2) pct_CLUSTER_WAIT_TIME
      ,round((xCONCURRENCY_WAIT_TIME/case when xELAPSED_TIME = 0 then null else xELAPSED_TIME end)*100,2) pct_CONCURRENCY_WAIT_TIME
      ,round((xUSER_IO_WAIT_TIME/case when xELAPSED_TIME = 0 then null else xELAPSED_TIME end)*100,2) pct_USER_IO_WAIT_TIME
      ,round((xPLSQL_EXEC_TIME/case when xELAPSED_TIME = 0 then null else xELAPSED_TIME end)*100,2) pct_PLSQL_EXEC_TIME
      ,round((xJAVA_EXEC_TIME/case when xELAPSED_TIME = 0 then null else xELAPSED_TIME end)*100,2) pct_JAVA_EXEC_TIME
      ,round((xCPU_TIME/case when xELAPSED_TIME = 0 then null else xELAPSED_TIME end)*100,2) pct_CPU_TIME
      ,round((xELAPSED_TIME - (xCPU_TIME+xJAVA_EXEC_TIME+xPLSQL_EXEC_TIME+xUSER_IO_WAIT_TIME+xCONCURRENCY_WAIT_TIME+xCLUSTER_WAIT_TIME))/case when xELAPSED_TIME = 0 then null else xELAPSED_TIME end*100,2) other_pct
from (
        select 
               inst_id
              ,trunc(log(10,mycpu_time)) cpu_time_log10
              ,count(*) sql_statements
              ,power(10,trunc(log(10,mycpu_time))) cpu_time_rounded
              ,sum(mycpu_time) cpu_time
--
              ,sum(xELAPSED_TIME) xELAPSED_TIME
              ,sum(xCLUSTER_WAIT_TIME) xCLUSTER_WAIT_TIME
              ,sum(xCONCURRENCY_WAIT_TIME) xCONCURRENCY_WAIT_TIME
              ,sum(xUSER_IO_WAIT_TIME) xUSER_IO_WAIT_TIME
              ,sum(xPLSQL_EXEC_TIME) xPLSQL_EXEC_TIME
              ,sum(xJAVA_EXEC_TIME) xJAVA_EXEC_TIME
              ,sum(xCPU_TIME) xCPU_TIME
        from (
               select inst_id,case when cpu_time <= 0 then 1 else cpu_time end/1000000 mycpu_time
--
                     ,ELAPSED_TIME xELAPSED_TIME
                     ,CLUSTER_WAIT_TIME xCLUSTER_WAIT_TIME
                     ,CONCURRENCY_WAIT_TIME xCONCURRENCY_WAIT_TIME
                     ,USER_IO_WAIT_TIME xUSER_IO_WAIT_TIME
                     ,PLSQL_EXEC_TIME xPLSQL_EXEC_TIME
                     ,JAVA_EXEC_TIME xJAVA_EXEC_TIME
                     ,CPU_TIME xCPU_TIME
               from gv$sqlarea
               where trim(upper(sql_text)) not like 'BEGIN%'
               and trim(upper(sql_text)) not like 'DECLARE%'
               and trim(upper(sql_text)) not like 'CALL%'
             )
        group by trunc(log(10,mycpu_time)),inst_id
     ) a
order by a.inst_id,a.cpu_time_log10
/

clear computes
col sql_text format a300
col sql_text clear

col sql_text format a300 trunc
col sql_helper_text format a32
col module format a30 word
col sec_per_exec format 999999990.0
--compute sum of cpu_seconds on inst_id , report
break on inst_id dup skip page
--
-- show use the actual SQL that exceeds some threshhold
-- these are the queries we want to concentrate on
-- configure the last AND predicate to whatever is reasonable based on the above query
--
select
       inst_id
      ,sql_id
      ,child_number
      ,trunc(cpu_time/1000000) cpu_seconds
      ,trunc(elapsed_time/1000000) eplapsed_seconds
      ,executions
      ,round(trunc(cpu_time/1000000)/decode(executions,0,null,executions),1) cpu_sec_per_exec
      ,round(trunc(elapsed_time/1000000)/decode(executions,0,null,executions),1) ela_sec_per_exec
      ,round((sysdate-to_date(first_load_time,'rrrr-mm-dd/hh24:mi:ss'))*24) hours_in_cache
      ,module
--      ,address
--      ,hash_value
      ,(select 'Open' from gv$open_cursor b where b.inst_id = a.inst_id and b.address = a.address and b.hash_value = a.hash_value and rownum = 1) open
/*
      ,case when sql_text like '%SELECT /*+ ORDERED NO_EXPAND USE_HASH%' or sql_text like '%FROM :Q%' or instr(sql_text,'CIV_GB') > 0 or instr(sql_text,'PIV_GB') > 0 or instr(sql_text,'PIV_SSF') > 0 or instr(sql_text,'SWAP_JOIN_INPUTS') > 0 then 'Slave'
            when sql_text like '%SELECT /*+ Q%' then 'Query'
            else (select 'Yes' from gv$sql_plan b where b.inst_id = a.inst_id and b.address = a.address and b.hash_value = a.hash_value and b.child_number = a.child_number and b.other_tag like 'PARALLEL%' and rownum = 1) 
       end parallel
*/
      ,'@showsqlall11g '||inst_id||' '||sql_id||' '||child_number sql_helper_text
      ,round((CLUSTER_WAIT_TIME/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end)*100,2) pct_CLUSTER_WAIT_TIME
      ,round((CONCURRENCY_WAIT_TIME/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end)*100,2) pct_CONCURRENCY_WAIT_TIME
      ,round((USER_IO_WAIT_TIME/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end)*100,2) pct_USER_IO_WAIT_TIME
      ,round((PLSQL_EXEC_TIME/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end)*100,2) pct_PLSQL_EXEC_TIME
      ,round((JAVA_EXEC_TIME/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end)*100,2) pct_JAVA_EXEC_TIME
      ,round((CPU_TIME/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end)*100,2) pct_CPU_TIME
      ,round((ELAPSED_TIME - (CPU_TIME+JAVA_EXEC_TIME+PLSQL_EXEC_TIME+USER_IO_WAIT_TIME+CONCURRENCY_WAIT_TIME+CLUSTER_WAIT_TIME))/case when ELAPSED_TIME = 0 then null else ELAPSED_TIME end*100,2) other_pct
      ,replace(sql_text,chr(13),' ') sql_text
from gv$sql a
where trim(upper(sql_text)) not like 'BEGIN%'
and trim(upper(sql_text)) not like 'DECLARE%'
and trim(upper(sql_text)) not like 'CALL%'
and cpu_time/1000000 >= 1000
--and cpu_time/1000000 >= 100
order by 1,4,5
/
