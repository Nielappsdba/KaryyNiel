col file_name for a100
--col size(MB) for a20
select file_name, round(sum(bytes)/1024/1024,4) "size(MB)" 
from dba_data_files
where 1=1
and tablespace_name like upper('&1%')
group by file_name;