-- Copyright 2018 Tanel Poder. All rights reserved. More info at http://tanelpoder.com
-- Licensed under the Apache License, Version 2.0. See LICENSE.txt for terms & conditions.

set line 200;
col name for a25;
col value for a75
SELECT * FROM v$diag_info;

