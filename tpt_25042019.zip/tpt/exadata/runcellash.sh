#!/bin/bash

./cellash.sh | cellcli > cellash.txt

